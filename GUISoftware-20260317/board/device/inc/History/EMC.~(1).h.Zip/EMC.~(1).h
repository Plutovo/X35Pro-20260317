#ifndef __UART_H
#define __UART_H

#define UART_FCR_FIFO_EN		((uint8_t)(1<<0))
#define UART_FCR_RX_RS			((uint8_t)(1<<1))
#define UART_FCR_TX_RS			((uint8_t)(1<<2))
#define UART_FCR_DMAMODE_SEL 	((uint8_t)(1<<3))
#define UART_FCR_TRG_LEV0		((uint8_t)(0))
#define UART_FCR_TRG_LEV1		((uint8_t)(1<<6))
#define UART_FCR_TRG_LEV2		((uint8_t)(2<<6))
#define UART_FCR_TRG_LEV3		((uint8_t)(3<<6))
#define UART_LSR_RDR		((uint8_t)(1<<0))

#define UART_LSR_OE			((uint8_t)(1<<1))
#define UART_LSR_PE			((uint8_t)(1<<2))
#define UART_LSR_FE			((uint8_t)(1<<3))/** Line status register: Break interrupt*/
#define UART_LSR_BI			((uint8_t)(1<<4))
#define UART_LSR_THRE		((uint8_t)(1<<5))
#define UART_LSR_TEMT		((uint8_t)(1<<6))
#define UART_LSR_RXFE		((uint8_t)(1<<7))

void UART_Init(unsigned int BR);

#endif

